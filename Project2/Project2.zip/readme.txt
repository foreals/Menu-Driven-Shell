Compile using "clang menushell.c -o menushell".

